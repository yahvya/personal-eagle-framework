# Framework Sabo

> Sabo est un framework php visant à faciliter le développement d'applications web tout en conservant le plaisir d'écrire du PHP.

*Le site de documentation du framework est en cours de création. [Suivez le développement](https://github.com/yahvya/sabo-final-doc)*

## Créer un projet

*Accédez aux releases du projet afin de télécharger le zip de la version la plus récente*
[Accès aux releases](https://github.com/yahvya/sabo-final/releases)

