<?php

namespace SaboCore\Config;

use Exception;

/**
 * @brief Exception de configuration
 * @author yahaya bathily https://github.com/yahvya/
 */
class ConfigException extends Exception {

}