<?php

namespace SaboCore\Controller;

/**
 * @brief Controller abstrait
 * @author yahaya bathily https://github.com/yahvya
 */
abstract class Controller{
    public function __construct(){}
}