<?php

namespace Controllers;

use SaboCore\Controller\Controller;

/**
 * @brief Controller customisé de l'application
 */
abstract class CustomController extends Controller{

}