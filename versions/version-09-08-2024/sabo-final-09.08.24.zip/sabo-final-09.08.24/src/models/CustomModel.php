<?php

namespace Models;

use SaboCore\Database\Default\System\MysqlModel;

/**
 * @brief Model customisé de l'application
 */
abstract class CustomModel extends MysqlModel {

}