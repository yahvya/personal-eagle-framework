<?php

namespace Treatment;

use SaboCore\Treatment\Treatment;

/**
 * @brief Gestionnaire de traitement customisé
 */
abstract class CustomTreatment extends Treatment{
}